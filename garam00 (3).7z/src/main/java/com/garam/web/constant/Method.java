package com.garam.web.constant;

public enum Method {
	GET, POST, PUT, PATCH, DELETE
}
