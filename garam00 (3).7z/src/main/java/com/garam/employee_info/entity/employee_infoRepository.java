package com.garam.employee_info.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface employee_infoRepository extends JpaRepository<employee_info, String> {

}
