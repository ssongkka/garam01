package com.garam.vehicle_info.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface vehicle_infoRepository extends JpaRepository<vehicle_info, String> {

}
